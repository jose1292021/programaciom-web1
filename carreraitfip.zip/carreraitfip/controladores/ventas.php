<script src="../js/sweetalert2@10.js"></script>
.
<?php
require "../config/conexion.php";

$documento = $_POST["documento"];
$nombre = $_POST["nombre"];
$carrera = $_POST["carrera"];

    $sql = "INSERT INTO carrera
    (documento, nombre, carrera, fecha_sys) VALUES 
    ('".$documento."','".$nombre."','".$carrera."',now())";

if ($conexion->query($sql)){
    echo "<script>
    Swal.fire({
      title: 'Registro exitoso',
      icon: 'success',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../index.html';
      }
    });
  </script>";
}
   else
{
    echo "<script>
    Swal.fire({
      title: 'Error al registrarse',
      icon: 'error',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../index.html';
      }
    });
  </script>";
}

?>