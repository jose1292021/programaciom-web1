<?php

require "../config/conexion.php";

$celular_cliente = $_POST["celular_cliente"];
$valor = $_POST["valor"];
$pin = $_POST["pin"];


$sql = " INSERT INTO transferencia (celular_cliente, valor, fecha_sys) VALUES ('".$celular_cliente."' ,'".$valor."' , now()) ";

if ($conexion->query($sql))
{
    echo "transferencia exitosa";
}else
    {
        echo "error transfiriendo dinero";
    }


echo " el pin digite fue: ";
echo $pin;
echo " el valor fue: ".$valor;

if($pin == 5555 and $valor >1000)
{
    echo " transferencia exitosa";

}else{
    echo " transfencia fallida";
}

?>