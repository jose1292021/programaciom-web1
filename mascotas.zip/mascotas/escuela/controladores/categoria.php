<?php
include "config/conexion.php";

$sql ="SELECT cod, categoria
FROM categoria 
WHERE 1";

foreach($conexion->query($sql) as $row)
{
    $cod = $row[0];
    $categoria = $row[1];
    print "
    <option value='".$cod."'> ".$categoria." </option>
    ";
}