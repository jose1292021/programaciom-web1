<script src="../js/sweetalert2@10.js"></script>
.
<?php
require "../config/conexion.php";
$nombre = $_POST["nombre"];
$id_categoria = $_POST["id_categoria"];

$sql = "INSERT INTO cuento (nombre, id_categoria, fecha_sys) VALUES ( '".$nombre."', ".$id_categoria.", now())";

if ($conexion->query($sql))
{
    echo "<script>
    Swal.fire({
      title: 'envio exitoso',
      icon: 'success',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {   
      if (result.isConfirmed) {
        window.location.href = '../enviar.php';
      }
    });
  </script>";
} else
{
    echo "<script>
    Swal.fire({
      title: 'error en el envio',
      icon: 'error',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../enviar.php';
      }
    });
  </script>";
}
?>