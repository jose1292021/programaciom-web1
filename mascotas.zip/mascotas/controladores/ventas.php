<script src="../js/sweetalert2@10.js"></script>
.
<?php
require "../config/conexion.php";

$nombre = $_POST["nombre"];

    $sql = "INSERT INTO mascota
    (nombre, fecha_sys) VALUES 
    ('".$nombre."',now())";

if ($conexion->query($sql)){
    echo "<script>
    Swal.fire({
      title: 'Registro exitoso',
      icon: 'success',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../registro.php';
      }
    });
  </script>";
}
   else
{
    echo "<script>
    Swal.fire({
      title: 'Error al registrarse',
      icon: 'error',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../registro.php';
      }
    });
  </script>";
}

?>