<?php

include"config/conexion.php";

$nombre = $_POST["nombre"];

$sql = "SELECT nombre, fecha_sys FROM mascota
WHERE nombre like '%".$nombre."%'";

$i=1;

foreach($conexion->query($sql) as $row){
    
    $nombre = $row['nombre'];
    $fecha_sys = $row['fecha_sys'];


print "
<tr>
<td>".$i."</td>
<td>".$nombre."</td>
<td>".$fecha_sys."</td>
</tr>
";
}
?>