<?php
include "config/conexion.php";

$sql ="SELECT id, nombre, fecha_sys FROM razas WHERE 1";

foreach($conexion->query($sql) as $row)
{
    $id = $row[0];
    $nombre = $row[1];
    print "
    <option value='".$id."'> ".$nombre." </option>
    ";
}