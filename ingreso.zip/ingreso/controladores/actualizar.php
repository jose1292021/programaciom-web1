
<script src="../js/sweetalert2@10.js"></script>
.
<?php
require "../config/conexion.php";
$id= $_POST["id"];
$documento = $_POST["documento"];
$nombre= $_POST["nombre"];
$edad = $_POST["edad"];
$habitacion = $_POST["habitacion"];
$nombre_pareja = $_POST["nombre_pareja"];
$doc_pareja = $_POST["doc_pareja"];
$edad_pareja = $_POST["edad_pareja"];

$sql = "UPDATE ingresohabitacion SET 
documento='".$documento."',nombre='".$nombre."',edad='".$edad."' 
,habitacion='".$habitacion."' ,nombre_pareja='".$nombre_pareja."' ,doc_pareja='".$doc_pareja."' , edad_pareja='".$edad_pareja."' WHERE id=".$id."";
if ($conexion->query($sql))
{
    echo  "<script>
    Swal.fire({
      title: 'ACTUALIZADO CORRECTAMENTE',
      icon: 'success',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../actualizar.html';
      }
    });
  </script>";
}
   else
{
    echo "<script>
    Swal.fire({
      title: 'ERROR AL ACTUALIZAR',
      icon: 'error',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../actualizar.html';
      }
    });
  </script>";
}
?>