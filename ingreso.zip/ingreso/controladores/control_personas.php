<?php
//Paso 1
include "config/conexion.php";

//paso 3
$sql =  "SELECT id, documento, nombre, edad,	habitacion, nombre_pareja, doc_pareja, edad_pareja, fecha_sys 
FROM ingresohabitacion WHERE 1";

//paso 4
foreach($conexion->query($sql) as $fila){
    $id = $fila['id'];
    $documento = $fila['documento'];
    $nombre = $fila['nombre'];
    $edad = $fila['edad'];
    $habitacion = $fila['habitacion'];
    $nombre_pareja = $fila['nombre_pareja'];
    $doc_pareja = $fila['doc_pareja'];
    $edad_pareja = $fila['edad_pareja'];
    print "
    <tr>
        <td>".$id." </td>
        <td>".$documento." </td>
        <td>".$nombre."</td>
        <td>".$edad."</td>
        <td>".$habitacion."</td>
        <td>".$nombre_pareja."</td>
        <td>".$doc_pareja."</td>
        <td>".$edad_pareja."</td>
        <td>".$fila['fecha_sys']."</td>
        
      </tr>
    ";
}
?>