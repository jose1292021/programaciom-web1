<script src="../js/sweetalert2@10.js"></script>
.
<?php
require "../config/conexion.php";
$documento= $_POST["documento"];
$nombre= $_POST["nombre"];
$edad= $_POST["edad"];
$habitacion= $_POST["habitacion"];
$nombre_pareja= $_POST["nombre_pareja"];
$doc_pareja= $_POST["doc_pareja"];
$edad_pareja= $_POST["edad_pareja"];

if($edad <=17 && $edad_pareja<=17){
    echo ("<script>
    Swal.fire({
      title: 'NO PODEMOS REGISTRAR MENORES',
      icon: 'error',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../index.html';
      }
    });
  </script>");
    exit;
}

$sql = " INSERT INTO ingresohabitacion (documento, nombre, edad, habitacion, nombre_pareja, doc_pareja, edad_pareja, fecha_sys)
     VALUES ('".$documento."' , '".$nombre."', '".$edad."' , '".$habitacion."' , '".$nombre_pareja."' , '".$doc_pareja."' , '".$edad_pareja."' , now())";

if ($conexion->query($sql)) {
    echo "<script>
    Swal.fire({
      title: 'REGISTRADO CORRECTAMENTE',
      icon: 'success',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../index.html';
      }
    });
  </script>";
} else {
    echo "<script>
    Swal.fire({
      title: 'ERROR AL INSERTAR EN LA BASE DE DATOS',
      icon: 'error',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../index.html';
      }
    });
  </script>";
}
