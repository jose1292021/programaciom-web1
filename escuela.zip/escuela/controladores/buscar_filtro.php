<?php
include "config/conexion.php";

$nombre = $_POST["nombre"];

$sql = "SELECT nombre, id_categoria, fecha_sys 
FROM cuento 
WHERE nombre = '".$nombre."' ";

$i=1;
foreach($conexion->query($sql) as $row)
{
    $nombre = $row["nombre"];
    $id_categoria = $row["id_categoria"];
    $fecha_sys = $row["fecha_sys"];

    print "
    <tr>
    <td>$i</td>
    <td>$nombre</td>
    <td>$id_categoria</td>
    <td>$fecha_sys</td>
  </tr>
    ";
    $i++;
}