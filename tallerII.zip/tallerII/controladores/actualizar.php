
<script src="../js/sweetalert2@10.js"></script>
.
<?php
require "../config/conexion.php";
$id= $_POST["id"];
$programa = $_POST["programa"];
$cedula= $_POST["cedula"];
$nombre = $_POST["nombre"];
$sql = "UPDATE uni SET 
programa='".$programa."',cedula=".$cedula.",nombre='".$nombre."' WHERE id=".$id."";
if ($conexion->query($sql))
{
    echo  "<script>
    Swal.fire({
      title: 'ACTUALIZADO CORRECTAMENTE',
      icon: 'success',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../actualizar.html';
      }
    });
  </script>";
}
   else
{
    echo "<script>
    Swal.fire({
      title: 'ERROR AL ACTUALIZAR',
      icon: 'error',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../actualizar.html';
      }
    });
  </script>";
}
?>