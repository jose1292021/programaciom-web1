<script src="../js/sweetalert2@10.js"></script>
.
<?php
require "../config/conexion.php";
$estado=0;
$programa = $_POST["programa"];
$cedula = $_POST["cedula"];
$nombre = $_POST["nombre"];

if ($estado==1)
 {
    echo ("<script>
    Swal.fire({
      title: 'plataforma cerrada',
      icon: 'error',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../index.html';
      }
    });
  </script>");
}
    $sql = "INSERT INTO uni
    (programa, cedula, nombre, fecha_sys) VALUES
    ('".$programa."',".$cedula.",'".$nombre."',now() )";
if ($conexion->query($sql))


{
    echo "<script>
    Swal.fire({
      title: 'Registro exitoso de pre-inscricion',
      icon: 'success',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../index.html';
      }
    });
  </script>";
}
   else
{
    echo "<script>
    Swal.fire({
      title: 'Error al registrar la pre_inscricion',
      icon: 'error',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../index.html';
      }
    });
  </script>";
}

?>