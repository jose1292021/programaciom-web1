<script src="../js/sweetalert2@10.js"></script>
.
<?php
require "../config/conexion.php";

$valorunitario = $_POST["valorunitario"];
$cantidad = $_POST["cantidad"];
$subtotal = $valorunitario*$cantidad;
$iva = $subtotal*0.19;
$total = $subtotal+$iva;

    $sql = "INSERT INTO disco
    (valorunitario, cantidad, subtotal, iva, total, fecha_sys) VALUES 
    ('".$valorunitario."','".$cantidad."','".$subtotal."', '".$iva."', '".$total."', now())";

if ($conexion->query($sql)){
    echo "<script>
    Swal.fire({
      title: 'Registro exitoso',
      icon: 'success',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../index.html';
      }
    });
  </script>";
}
   else
{
    echo "<script>
    Swal.fire({
      title: 'Error al registrarse',
      icon: 'error',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../index.html';
      }
    });
  </script>";
}

?>