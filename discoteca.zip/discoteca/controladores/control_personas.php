<?php
//Paso 1
include "config/conexion.php";

//paso 3
$sql =  "SELECT id, valorunitario, cantidad, subtotal, iva, total, fecha_sys 
FROM disco WHERE 1";

//paso 4
foreach($conexion->query($sql) as $fila){
    $id = $fila['id'];
    $valorunitario = $fila['valorunitario'];
    $cantidad = $fila['cantidad'];
    $subtotal = $fila['subtotal'];
    $iva = $fila['iva'];
    $total = $fila['total'];
    print "
    <tr>
        <td>".$id." </td>
        <td>".$valorunitario." </td>
        <td>".$cantidad."</td>
        <td>".$subtotal."</td>
        <td>".$iva."</td>
        <td>".$total."</td>
        <td>".$fila['fecha_sys']."</td>
        
      </tr>
    ";
}
?>