<script src="../js/sweetalert2@10.js"></script>
.
<?php

require "../config/conexion.php";

$celular_cliente = $_POST["celular_cliente"];
$valor = $_POST["valor"];
$pin = $_POST["pin"];


$sql = " INSERT INTO transferencia (celular_cliente, valor, fecha_sys) VALUES ('".$celular_cliente."' ,'".$valor."' , now()) ";

if ($conexion->query($sql))
{
    echo "<script>
    Swal.fire({
      title: 'Transferencia exitosa',
      icon: 'success',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../index.html';
      }
    });
  </script>";
}else
    {
        echo "<script>
        Swal.fire({
          title: 'Error en la transferencia',
          icon: 'error',
          confirmButtonColor: '#3085d6',
          confirmButtonText: 'Aceptar'
        }).then((result) => {
          if (result.isConfirmed) {
            window.location.href = '../index.html';
          }
        });
      </script>";
    }


?>