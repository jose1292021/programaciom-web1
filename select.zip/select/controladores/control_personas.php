<?php
//Paso 1
include "config/conexion.php";

//paso 3
$sql =  "SELECT id, celular_cliente, valor, fecha_sys 
FROM transferencia WHERE 1";

//paso 4
foreach($conexion->query($sql) as $fila){
    $id = $fila['id'];
    $celular_cliente = $fila[2];
    $valor = $fila['valor'];
    print "
    <tr>
        <td>".$id." </td>
        <td>".$celular_cliente." </td>
        <td>".$valor."</td>
        <td>".$fila['fecha_sys']."</td>
        
      </tr>
    ";
}
?>