<?php
include "config/conexion.php";

$sql = "SELECT cod, nombre FROM programa WHERE 1";

foreach($conexion->query($sql) as $row){
    $cod = $row[0];
    $nombre = $row[1];
    print"
    <option value ='".$cod."'> ".$nombre." </option>";
}