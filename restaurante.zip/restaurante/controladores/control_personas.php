<?php
//Paso 1
include "config/conexion.php";

//paso 3
$sql =  "SELECT id, valorgastado, impuesto, iva, descuento, fecha_sys FROM restaurante WHERE 1";

//paso 4
foreach($conexion->query($sql) as $fila){
    $id = $fila['id'];
    $valorgastado = $fila['valorgastado'];
    $impuesto = $fila['impuesto'];
    $iva = $fila['iva'];
    $descuento = $fila['descuento'];
    print "
    <tr>
        <td>".$id." </td>
        <td>".$valorgastado." </td>
        <td>".$impuesto."</td>
        <td>".$iva."</td>
        <td>".$descuento."</td>
        <td>".$fila['fecha_sys']."</td>
        
      </tr>
    ";
}
?>