<script src="../js/sweetalert2@10.js"></script>
.
<?php

require "../config/conexion.php";

$nombre = $_POST["nombre"];
$edad = $_POST["edad"];
$celular = $_POST["celular"];
$email = $_POST["email"];
$fecha = $_POST["fecha"];

if ($edad >= 18){
  echo ("<script>
  Swal.fire({
    title: 'Registro exitoso',
    icon: 'success',
    confirmButtonColor: '#3085d6',
    confirmButtonText: 'Aceptar'
  }).then((result) => {
    if (result.isConfirmed) {
      window.location.href = '../index.html';
    }
  });
</script>");
}

$sql = " INSERT INTO only (nombre, edad, celular, email, fecha, fecha_sys) VALUES ('".$nombre."','".$edad."', '".$celular."', '".$email."', '".$fecha."', now()) ";

if ($conexion->query($sql))
{
    echo "<script>
    Swal.fire({
      title: 'Registro exitoso',
      icon: 'success',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../index.html';
      }
    });
  </script>";
}else
    {
        echo "<script>
        Swal.fire({
          title: 'Error no podemos registrarte ',
          icon: 'error',
          confirmButtonColor: '#3085d6',
          confirmButtonText: 'Aceptar'
        }).then((result) => {
          if (result.isConfirmed) {
            window.location.href = '../index.html';
          }
        });
      </script>";
    }


?>