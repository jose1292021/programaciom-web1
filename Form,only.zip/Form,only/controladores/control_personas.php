<?php
//Paso 1
include "config/conexion.php";

//paso 3
$sql =  "SELECT id, nombre, edad, celular, email, fecha_sys 
FROM only WHERE 1";

//paso 4
foreach($conexion->query($sql) as $fila){
    $id = $fila['id'];
    $nombre = $fila['nombre'];
    $edad = $fila['edad'];
    $celular = $fila['celular'];
    $email = $fila['email'];
    print "
    <tr>
        <td>".$id." </td>
        <td>".$nombre." </td>
        <td>".$edad."</td>
        <td>".$celular."</td>
        <td>".$email."</td>
        <td>".$fila['fecha_sys']."</td>
        
      </tr>
    ";
}
?>